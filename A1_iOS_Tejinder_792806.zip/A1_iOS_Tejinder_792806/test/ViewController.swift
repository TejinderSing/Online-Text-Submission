//
//  ViewController.swift
//  A1_iOS_Tejinder_792806
//
//  Created by Tejinder Singh on 5/17/21.
//

import UIKit

import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    @IBOutlet weak var map: MKMapView!
    
    @IBOutlet weak var locate: UIButton!
    var source:   CLLocation!
    
    var destination: CLLocation!
    
    var annot = [MKAnnotation]()
    
    var count = 0
    
    
    //MARK: - ViewLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        map.showsUserLocation = true
        map.isZoomEnabled = false
        
        map.delegate = self
        
        var locationMnager =   CLLocationManager()
        
        
        
        // 1st step is to define latitude and longitude
        let latitude: CLLocationDegrees = 43.64
        let longitude: CLLocationDegrees = -79.38
        
        // 2nd step is to display the marker on the map
            displayLocation(latitude: latitude, longitude: longitude, title: "my location", subtitle: "You are here")
        //Double tap function
        addDoubleTap()
        
        //single tap function
        //addsingleTap()
        
        //longpress fuunction
        //longPress()
    
    }
    //MARK: -Display Loction
    func displayLocation(latitude: CLLocationDegrees,
                         longitude: CLLocationDegrees,
                         title: String,
                         subtitle: String) {
        
        let latDelta: CLLocationDegrees = 0.05
        let lngDelta: CLLocationDegrees = 0.05
        
        let span = MKCoordinateSpan(latitudeDelta: latDelta, longitudeDelta: lngDelta)
        // 3rd step is to define the location
        let location = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        // 4th step is to define the region
        let region = MKCoordinateRegion(center: location, span: span)
        
        // 5th step is to set the region for the map
        map.setRegion(region, animated: true)
        
        // 6th step is to define annotation
        let annotation = MKPointAnnotation()
        annotation.title = title
        annotation.subtitle = subtitle
        annotation.coordinate = location
        map.addAnnotation(annotation)
    
    }
    //MARK: - Make route
    @IBAction func makeRoute(_ sender: UIButton) {
        map.isZoomEnabled = false
        map.removeOverlays(map.overlays)
        // for A to B
        for src in annot{
            if src.title == "A"{
                for des in annot{
                    if des.title == "B"{
                        let sourcePlaceMark = MKPlacemark(coordinate: src.coordinate)
                        let destinationPlaceMark = MKPlacemark(coordinate: des.coordinate)
                        
                        // request a direction
                        let directionRequest = MKDirections.Request()
                        
                        // assign the source and destination properties of the request
                        directionRequest.source = MKMapItem(placemark: sourcePlaceMark)
                        directionRequest.destination = MKMapItem(placemark: destinationPlaceMark)
                        
                        // transportation type
                        directionRequest.transportType = .automobile
                        
                        // calculate the direction
                        let directions = MKDirections(request: directionRequest)
                        directions.calculate { (response, error) in
                            guard let directionResponse = response else {return}
                            // create the route
                            let route = directionResponse.routes[0]
                            // drawing a polyline
                            self.map.addOverlay(route.polyline, level: .aboveRoads)
                            
                            // define the bounding map rect
                            let rect = route.polyline.boundingMapRect
                            self.map.setVisibleMapRect(rect, edgePadding: UIEdgeInsets(top: 100, left: 100, bottom: 100, right: 100), animated: true)
                            
              
                        }
                    }
                    else if des.title == "C"{
                        let sourcePlaceMark = MKPlacemark(coordinate: src.coordinate)
                        let destinationPlaceMark = MKPlacemark(coordinate: des.coordinate)
                        
                        // request a direction
                        let directionRequest = MKDirections.Request()
                        
                        // assign the source and destination properties of the request
                        directionRequest.source = MKMapItem(placemark: sourcePlaceMark)
                        directionRequest.destination = MKMapItem(placemark: destinationPlaceMark)
                        
                        // transportation type
                        directionRequest.transportType = .automobile
                        
                        // calculate the direction
                        let directions = MKDirections(request: directionRequest)
                        directions.calculate { (response, error) in
                            guard let directionResponse = response else {return}
                            // create the route
                            let route = directionResponse.routes[0]
                            // drawing a polyline
                            self.map.addOverlay(route.polyline, level: .aboveRoads)
                            
                            // define the bounding map rect
                            let rect = route.polyline.boundingMapRect
                            self.map.setVisibleMapRect(rect, edgePadding: UIEdgeInsets(top: 100, left: 100, bottom: 100, right: 100), animated: true)
          
                        }
                    }
                }
            }
            if src.title == "B"{
                for des in annot{
                    if des.title == "C"{
                        let sourcePlaceMark = MKPlacemark(coordinate: src.coordinate)
                        let destinationPlaceMark = MKPlacemark(coordinate: des.coordinate)
                        
                        // request a direction
                        let directionRequest = MKDirections.Request()
                        
                        // assign the source and destination properties of the request
                        directionRequest.source = MKMapItem(placemark: sourcePlaceMark)
                        directionRequest.destination = MKMapItem(placemark: destinationPlaceMark)
                        
                        // transportation type
                        directionRequest.transportType = .automobile
                        
                        // calculate the direction
                        let directions = MKDirections(request: directionRequest)
                        directions.calculate { (response, error) in
                            guard let directionResponse = response else {return}
                            // create the route
                            let route = directionResponse.routes[0]
                            // drawing a polyline
                            self.map.addOverlay(route.polyline, level: .aboveRoads)
                            
                            // define the bounding map rect
                            let rect = route.polyline.boundingMapRect
                            self.map.setVisibleMapRect(rect, edgePadding: UIEdgeInsets(top: 100, left: 100, bottom: 100, right: 100), animated: true)
                            
                        }
                    }
                }
            }
        }
    }
    //MARK: - Enable Zoom
    @IBAction func enableZoom(_ sender: UIButton) {
        if map.isZoomEnabled {
            map.isZoomEnabled = false
        }
        else{
            map.isZoomEnabled = true
        }
    }
    //MARK: -Single Tap
    
    //ain't working
//    func addsingleTap(){
//        let singleTap = UITapGestureRecognizer(target: self, action: #selector(removepin))
//        singleTap.numberOfTapsRequired = 1
//        map.addGestureRecognizer(singleTap)
//    }
//    @objc func removepin(sender: UITapGestureRecognizer){
//        let touchPoint = sender.location(in: map)
//        let coordinate = map.convert(touchPoint, toCoordinateFrom: map)
//        let regin = MKCoordinateRegion(center: coordinate, latitudinalMeters: 0.50, longitudinalMeters: 0.50)
//
//
//
//        for aon in annot{
//            let ouregion = MKCoordinateRegion(center: coordinate, latitudinalMeters: 0.50, longitudinalMeters: 0.50)
//
//            if {
//
//            }
//        }
//    }
    
    
    //MARK: - double tap func
    func addDoubleTap() {
        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(dropPin))
        doubleTap.numberOfTapsRequired = 2
        
        map.addGestureRecognizer(doubleTap)
        
    }
    
    @objc func dropPin(sender: UITapGestureRecognizer) {
        
                    
        count += 1
        // add annotation
        
        if count <= 3{
            let touchPoint = sender.location(in: map)
            let coordinate = map.convert(touchPoint, toCoordinateFrom: map)
            let annotation = MKPointAnnotation()
            if count == 1{
                annotation.title = "A"
            }
            else if count == 2 {
                annotation.title = "B"
            }
            else {
                annotation.title = "C"
            }
            annotation.coordinate = coordinate
            map.addAnnotation(annotation)
            annot.append(annotation )
        }
        
        if(count == 3){
            
            addPolygon()
            addPolyline()
        }
        else if count > 3{
            removeall()
        }
        
    }
//    //MARK: - Long Press Gesture
//    func longPress(){
//        let longpress = UILongPressGestureRecognizer(target: self, action: #selector(longpges))
//        longpress.minimumPressDuration = 1
//        longpress.allowableMovement = 0.23
//        map.addGestureRecognizer(longpress)
//    }
//    @objc func longpges(sender: UILongPressGestureRecognizer){
//        count += 1
//        // add annotation
//
//        if count <= 3{
//            let touchPoint = sender.location(in: map)
//            let coordinate = map.convert(touchPoint, toCoordinateFrom: map)
//            let annotation = MKPointAnnotation()
//            if count == 1{
//                annotation.title = "A"
//            }
//            else if count == 2 {
//                annotation.title = "B"
//            }
//            else {
//                annotation.title = "C"
//            }
//            annotation.coordinate = coordinate
//            map.addAnnotation(annotation)
//            annot.append(annotation )
//        }
//
//        if(count == 3){
//
//            addPolygon()
//            addPolyline()
//        }
//        else if count > 3{
//            removeall()
//        }
//
//
//    }
    //MARK: - Remove Function
    func removeall(){
        
        map.removeAnnotations(annot)
            map.removeOverlays(map.overlays)
        
        annot.removeAll()
        count = 0
        addDoubleTap()
    }
    //MARK: -Polygon function
    func addPolygon() {
        let coordinates = annot.map {$0.coordinate}
        let polygon = MKPolygon(coordinates: coordinates, count: coordinates.count)
        
        map.addOverlay(polygon)
    }
    //MARK: - Polyline method
    func addPolyline() {
        let coordinates = annot.map {$0.coordinate}
        let polyline = MKPolyline(coordinates: coordinates, count: coordinates.count)
       
        map.addOverlay(polyline)
    }
    // MARK: -Polygon and Polyline view
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if overlay is MKPolygon {
            let rendrer = MKPolygonRenderer(overlay: overlay)
            rendrer.fillColor = UIColor.red.withAlphaComponent(0.5)
            rendrer.strokeColor = UIColor.yellow
            rendrer.lineWidth = 2
            return rendrer
        }
        else if overlay is MKPolyline {
            let rendrer = MKPolylineRenderer(overlay: overlay)
            rendrer.strokeColor = UIColor.blue
            rendrer.lineWidth = 3
            return rendrer
        }
        return MKOverlayRenderer()
    }
    //MARK: -Annotation View
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
       
        switch annotation.title {
            case "my location":
                let annotationView = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: "MyMarker")
                    annotationView.markerTintColor = UIColor.blue
                return annotationView
            case "A":
                let annotationView = map.dequeueReusableAnnotationView(withIdentifier: "customPin") ?? MKPinAnnotationView()
                annotationView.image = UIImage(named: "ic_place_2x")
                annotationView.canShowCallout = true
                annotationView.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
                return annotationView
            case "B":
                let annotationView = map.dequeueReusableAnnotationView(withIdentifier: "customPin") ?? MKPinAnnotationView()
                annotationView.image = UIImage(named: "ic_place_2x")
                annotationView.canShowCallout = true
                annotationView.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
                return annotationView
            case "C":
                let annotationView = map.dequeueReusableAnnotationView(withIdentifier: "customPin") ?? MKPinAnnotationView()
                annotationView.image = UIImage(named: "ic_place_2x")
                annotationView.canShowCallout = true
                annotationView.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
                return annotationView
            default:
                return nil
        }
    }
    
    //MARK:- Callout function
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        //--------------------------
        for myloc in map.annotations{
            if myloc.title == "my location"{
                destination = CLLocation(latitude: myloc.coordinate.latitude, longitude: myloc.coordinate.longitude)
            }
        }
        //--------------------------
        
        
        
        for loc in map.annotations{
            switch loc.title {
            case "A":
                source = CLLocation(latitude: loc.coordinate.latitude, longitude: loc.coordinate.longitude)
                let alertController = UIAlertController(title: "Distance from your location in meters", message: String(source.distance(from: destination)), preferredStyle: .alert)
                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                alertController.addAction(cancelAction)
                present(alertController, animated: true, completion: nil)
            case "B":
                source = CLLocation(latitude: loc.coordinate.latitude, longitude: loc.coordinate.longitude)
                let alertController = UIAlertController(title: "Distance from your location in meters", message: String(source.distance(from: destination)), preferredStyle: .alert)
                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                alertController.addAction(cancelAction)
                present(alertController, animated: true, completion: nil)
            case "C":
                source = CLLocation(latitude: loc.coordinate.latitude, longitude: loc.coordinate.longitude)
                let alertController = UIAlertController(title: "Distance from your location in meters", message: String(source.distance(from: destination)), preferredStyle: .alert)
                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                alertController.addAction(cancelAction)
                present(alertController, animated: true, completion: nil)
            default:
                print("my location")
            }
        }
    }
    
}
